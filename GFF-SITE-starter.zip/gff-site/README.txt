GFF-SITE starter website

FILES
- index.html: complete responsive starter website.

HOW TO PREVIEW
Open index.html in a web browser.

HOW TO PUBLISH FOR FREE WITH GITHUB PAGES
1. Create/sign in to a GitHub account.
2. Create a new public repository named gff-site.
3. Upload index.html to the repository's main page (Add file > Upload files).
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish. Your address will look like:
   https://YOUR-USERNAME.github.io/gff-site/

IMPORTANT
This is a front-end starter website. The Staff Center is a visual preview only.
It does not provide real authentication, secure admin permissions, or a database.
Before using real staff accounts or storing league data, connect a secure backend
and authentication provider. Never put passwords or secret keys in this HTML file.

A custom domain is optional and usually costs money. Start with the free GitHub
Pages address; you can connect a domain later if you obtain one.
